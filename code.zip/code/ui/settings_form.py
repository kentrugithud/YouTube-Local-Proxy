from __future__ import annotations

import webbrowser
from dataclasses import dataclass
from typing import Any, Callable, List, Optional, Union

from proxy import __version__, coerce_domain_list
from ui.background_task import BackgroundTask
from ui.connectivity import run_cfworker_multi_test, show_multi_connectivity_results
from ui.ctk_controls import (
    create_entry, create_checkbox, create_label, create_labeled_entry,
    create_config_section, create_combobox,
)
from ui.ctk_theme import CtkTheme
from ui.ctk_tooltip import attach_ctk_tooltip, attach_tooltip_to_widgets
from ui.settings import validate_settings
from ui.i18n import (
    label_from_language, language_from_label, language_option_labels,
    set_language, t,
)
from utils.win_system_proxy import PROXY_OVERRIDE

RELEASES_URL = "https://github.com/kentrugithud/YouTube-Local-Proxy/releases/"
WORKER_HELP_URL = "https://kentrugit.github.io/cfw-ytlp/"

_INNER_W = 396
_APPEARANCE_KEYS = ("auto", "light", "dark")
_APPEARANCE_TO_CTK = {"auto": "system", "light": "Light", "dark": "Dark"}


def _appearance_options() -> List[str]:
    return [t(f"appearance.{key}") for key in _APPEARANCE_KEYS]


def _appearance_from_cfg(value: str) -> str:
    if value in _APPEARANCE_KEYS:
        return t(f"appearance.{value}")
    return t("appearance.auto")


def _appearance_to_cfg(label: str) -> str:
    for key in _APPEARANCE_KEYS:
        if t(f"appearance.{key}") == label:
            return key
    return "auto"


@dataclass
class TrayConfigFormWidgets:
    host_var: Any
    port_var: Any
    autostart_var: Optional[Any]
    cfproxy_worker_enabled_var: Optional[Any] = None
    cfproxy_worker_domain_var: Optional[Any] = None
    appearance_var: Optional[Any] = None
    language_var: Optional[Any] = None


def install_tray_config_form(
    ctk: Any,
    frame: Any,
    theme: CtkTheme,
    cfg: dict,
    default_config: dict,
    *,
    show_autostart: bool = False,
    autostart_value: bool = False,
    on_update_click: Optional[Callable[[], None]] = None,
) -> TrayConfigFormWidgets:
    set_language(cfg.get("language", default_config["language"]))

    _create_header(ctk, frame, theme)
    appearance_var, language_var = _create_interface(ctk, frame, theme, cfg, default_config)
    host_var, port_var = _create_connection(ctk, frame, theme, cfg, default_config)
    worker_enabled_var, worker_domain_var = _create_cfworker(
        ctk, frame, theme, cfg, default_config, bool(cfg.get("no_secure", False)),
    )
    _create_updates(ctk, frame, theme)
    autostart_var = _create_autostart(ctk, frame, theme, show_autostart, autostart_value)

    return TrayConfigFormWidgets(
        host_var=host_var, port_var=port_var,
        autostart_var=autostart_var,
        cfproxy_worker_enabled_var=worker_enabled_var,
        cfproxy_worker_domain_var=worker_domain_var,
        appearance_var=appearance_var,
        language_var=language_var,
    )


def _create_header(ctk, frame, theme):
    header = ctk.CTkFrame(frame, fg_color="transparent")
    header.pack(fill="x", pady=(0, 2))
    ctk.CTkLabel(
        header, text=t("settings.title"),
        font=(theme.ui_font_family, 17, "bold"),
        text_color=theme.text_primary, anchor="w",
    ).pack(side="left")
    ctk.CTkLabel(
        header, text=f"v{__version__}",
        font=(theme.ui_font_family, 12),
        text_color=theme.text_secondary, anchor="e",
    ).pack(side="right", padx=(4, 0))


def _create_interface(ctk, frame, theme, cfg, default_config):
    lang_cfg = cfg.get("language", default_config["language"])
    appearance_var = ctk.StringVar(
        master=frame, value=_appearance_from_cfg(cfg.get("appearance", "auto"))
    )

    def _on_appearance_change(choice: str) -> None:
        cfg_val = _appearance_to_cfg(choice)
        ctk.set_appearance_mode(_APPEARANCE_TO_CTK[cfg_val])

    ui_inner = create_config_section(ctk, frame, theme, t("section.interface"))
    ui_row = ctk.CTkFrame(ui_inner, fg_color="transparent")
    ui_row.pack(fill="x")

    lang_col = ctk.CTkFrame(ui_row, fg_color="transparent")
    lang_col.pack(side="left", fill="x", expand=True, padx=(0, 8))

    theme_col = ctk.CTkFrame(ui_row, fg_color="transparent")
    theme_col.pack(side="left", fill="x", expand=True, padx=(8, 0))

    language_var = ctk.StringVar(master=frame, value=label_from_language(lang_cfg))
    create_label(ctk, lang_col, theme, t("settings.language"), size=11).pack(
        anchor="w", pady=(0, 2)
    )
    create_combobox(
        ctk, lang_col, theme, variable=language_var,
        values=[label for _, label in language_option_labels()],
    ).pack(fill="x")
    create_label(ctk, theme_col, theme, t("settings.theme"), size=11).pack(
        anchor="w", pady=(0, 2)
    )
    create_combobox(
        ctk, theme_col, theme, variable=appearance_var,
        values=_appearance_options(), command=_on_appearance_change,
    ).pack(fill="x")
    return appearance_var, language_var


def _create_connection(ctk, frame, theme, cfg, default_config):
    conn = create_config_section(ctk, frame, theme, t("section.connection"))

    host_row = ctk.CTkFrame(conn, fg_color="transparent")
    host_row.pack(fill="x")

    host_col, host_var = create_labeled_entry(
        ctk, host_row, theme, t("label.host"),
        cfg.get("host", default_config["host"]), width=160, pack_fill=True,
    )
    host_col.pack(side="left", fill="x", expand=True, padx=(0, 10))

    port_col, port_var = create_labeled_entry(
        ctk, host_row, theme, t("label.port"),
        cfg.get("port", default_config["port"]), width=100,
    )
    port_col.pack(side="left")

    # Что вставить в Windows: «Не использовать прокси-сервер для адресов…»
    exc_col = ctk.CTkFrame(conn, fg_color="transparent")
    exc_col.pack(fill="x")
    create_label(ctk, exc_col, theme, t("label.exceptions")).pack(anchor="w", pady=(0, 2))
    exc_var = ctk.StringVar(master=frame, value=PROXY_OVERRIDE)
    exc_entry = create_entry(ctk, exc_col, theme, var=exc_var)
    exc_entry.pack(fill="x")
    exc_entry.configure(state="readonly")
    return host_var, port_var


def _create_cfworker(ctk, frame, theme, cfg, default_config, no_secure):
    inner = create_config_section(ctk, frame, theme, t("section.cfworker"))

    row = ctk.CTkFrame(inner, fg_color="transparent")
    row.pack(fill="x", pady=(0, 4))
    lbl = create_label(ctk, row, theme, t("label.cfworker_domains"), size=11)
    lbl.pack(side="left", anchor="w", pady=(0, 2))

    input_row = ctk.CTkFrame(inner, fg_color="transparent")
    input_row.pack(fill="x")

    saved_domains = coerce_domain_list(
        cfg.get("cfproxy_worker_domain", default_config.get("cfproxy_worker_domain", ""))
    )
    enabled_var = ctk.BooleanVar(
        master=frame, value=cfg.get("cfproxy_worker_enabled", bool(saved_domains))
    )
    cb = create_checkbox(ctk, input_row, theme, t("label.cf_custom_domain"), enabled_var)
    cb.pack(side="left", padx=(0, 10))
    attach_ctk_tooltip(cb, t("tip.cfworker_domain"))

    domain_var = ctk.StringVar(master=frame, value=", ".join(saved_domains))
    entry = create_entry(ctk, input_row, theme, var=domain_var, height=32, radius=8)
    entry.pack(side="left", fill="x", expand=True, padx=(0, 6))
    attach_tooltip_to_widgets([lbl, entry], t("tip.cfworker_domain"))

    test_task = BackgroundTask(frame.winfo_toplevel())

    def _sync_test_button(*_):
        enabled = (
            not test_task.running and enabled_var.get()
            and bool(coerce_domain_list(domain_var.get()))
        )
        test_btn.configure(state="normal" if enabled else "disabled")

    def _on_test():
        domains = coerce_domain_list(domain_var.get())
        if test_task.running or not enabled_var.get() or not domains:
            return
        test_btn.configure(text=t("button.test_loading"), state="disabled")

        def finish():
            test_btn.configure(text=t("button.test"))
            _sync_test_button()

        test_task.start(
            lambda: run_cfworker_multi_test(domains, secure=not no_secure),
            lambda per: show_multi_connectivity_results(
                per, parent=frame.winfo_toplevel()),
            finish,
        )

    ctk.CTkButton(
        input_row, text="?", width=28, height=32,
        font=(theme.ui_font_family, 14), corner_radius=8,
        fg_color=theme.accent, hover_color=theme.accent_hover,
        text_color="#ffffff", border_width=1, border_color=theme.field_border,
        command=lambda: webbrowser.open(WORKER_HELP_URL),
    ).pack(side="right")

    test_btn = ctk.CTkButton(
        row, text=t("button.test"), width=56, height=28,
        font=(theme.ui_font_family, 13), corner_radius=8,
        fg_color=theme.accent, hover_color=theme.accent_hover,
        text_color="#ffffff", border_width=1, border_color=theme.field_border,
        command=_on_test,
    )
    test_btn.pack(side="right")

    def _sync_entry(*_):
        entry.configure(state="normal" if enabled_var.get() else "disabled")
        _sync_test_button()

    enabled_var.trace_add("write", _sync_entry)
    domain_var.trace_add("write", _sync_test_button)
    _sync_entry()
    return enabled_var, domain_var


def _create_updates(ctk, frame, theme):
    inner = create_config_section(ctk, frame, theme, t("section.updates"))
    ctk.CTkButton(
        inner, text=t("button.open_release"), height=32,
        font=(theme.ui_font_family, 13), corner_radius=8,
        fg_color=theme.field_bg, hover_color=theme.field_border,
        text_color=theme.text_primary, border_width=1,
        border_color=theme.field_border,
        command=lambda: webbrowser.open(RELEASES_URL),
    ).pack(fill="x")


def _create_autostart(ctk, frame, theme, show_autostart, autostart_value):
    autostart_var = None
    if show_autostart:
        sys_inner = create_config_section(ctk, frame, theme, t("section.windows_startup"), bottom_spacer=4)
        autostart_var = ctk.BooleanVar(master=frame, value=autostart_value)
        as_cb = create_checkbox(ctk, sys_inner, theme, t("label.autostart"), autostart_var)
        as_cb.pack(anchor="w", pady=(0, 4))
        as_hint = create_label(
            ctk, sys_inner, theme,
            t("label.autostart_hint"),
            size=11, justify="left", wraplength=_INNER_W,
        )
        as_hint.pack(anchor="w")
        attach_tooltip_to_widgets([as_cb, as_hint], t("tip.autostart"))
    return autostart_var


def validate_config_form(
    widgets: TrayConfigFormWidgets,
    default_config: dict,
    *,
    include_autostart: bool,
) -> Union[dict, str]:
    values = {
        "host": widgets.host_var.get(),
        "port": widgets.port_var.get(),
    }
    if widgets.cfproxy_worker_enabled_var is not None:
        values["cfproxy_worker_enabled"] = bool(widgets.cfproxy_worker_enabled_var.get())
    if widgets.cfproxy_worker_domain_var is not None:
        values["cfproxy_worker_domain"] = widgets.cfproxy_worker_domain_var.get()
    if include_autostart:
        values["autostart"] = (
            bool(widgets.autostart_var.get())
            if widgets.autostart_var is not None else False
        )
    if widgets.appearance_var is not None:
        values["appearance"] = _appearance_to_cfg(widgets.appearance_var.get())
    if widgets.language_var is not None:
        values["language"] = language_from_label(widgets.language_var.get()).value
    return validate_settings(values, default_config)
